A Pen created at CodePen.io. You can find this one at http://codepen.io/tari/pen/mVdLXy.

 color resource - http://colorhunt.co/c/6998